import { storage } from './storage';
import { delay } from './api';
import { TravelPost, TravelPhoto, TravelCarouselSettings } from '../types';

export const travelService = {
  getTravelPosts: async (): Promise<TravelPost[]> => {
    await delay(150);
    return storage.getTravel();
  },

  getTravelPostById: async (id: string): Promise<TravelPost | undefined> => {
    await delay(150);
    const posts = storage.getTravel();
    return posts.find((p) => p.id === id);
  },

  createTravelPost: async (post: Omit<TravelPost, 'id' | 'updatedAt'>): Promise<TravelPost> => {
    await delay(300);
    const posts = storage.getTravel();
    const newPost: TravelPost = {
      ...post,
      id: `trv_${Date.now()}`,
      order: post.order || posts.length + 1,
      updatedAt: new Date().toISOString(),
    };
    const updated = [newPost, ...posts];
    storage.setTravel(updated);
    storage.addActivity(`Created travel journal post "${newPost.location}"`, 'Travel');
    return newPost;
  },

  updateTravelPost: async (id: string, updates: Partial<TravelPost>): Promise<TravelPost> => {
    await delay(250);
    const posts = storage.getTravel();
    const index = posts.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Travel post not found');
    const updated = {
      ...posts[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    posts[index] = updated;
    storage.setTravel(posts);
    storage.addActivity(`Updated travel journal post "${updated.location}"`, 'Travel');
    return updated;
  },

  deleteTravelPost: async (id: string): Promise<void> => {
    await delay(250);
    const posts = storage.getTravel();
    const item = posts.find((p) => p.id === id);
    const filtered = posts.filter((p) => p.id !== id);
    storage.setTravel(filtered);
    if (item) {
      storage.addActivity(`Deleted travel post "${item.location}"`, 'Travel');
    }
  },

  updateCarouselSettings: async (
    id: string,
    settings: TravelCarouselSettings
  ): Promise<TravelPost> => {
    await delay(200);
    const posts = storage.getTravel();
    const post = posts.find((p) => p.id === id);
    if (!post) throw new Error('Travel post not found');
    post.carouselSettings = settings;
    storage.setTravel(posts);
    storage.addActivity(`Updated carousel slider settings for "${post.location}"`, 'Travel');
    return post;
  },

  updatePhotos: async (id: string, photos: TravelPhoto[]): Promise<TravelPost> => {
    await delay(250);
    const posts = storage.getTravel();
    const post = posts.find((p) => p.id === id);
    if (!post) throw new Error('Travel post not found');
    post.photos = photos;
    // Sync cover image if changed
    const coverPhoto = photos.find((p) => p.isCover);
    if (coverPhoto) {
      post.coverImage = coverPhoto.url;
    }
    storage.setTravel(posts);
    storage.addActivity(`Updated photos gallery for "${post.location}" (${photos.length} photos)`, 'Travel');
    return post;
  },

  reorderTravelPosts: async (reordered: TravelPost[]): Promise<TravelPost[]> => {
    await delay(200);
    const withUpdatedOrder = reordered.map((p, idx) => ({ ...p, order: idx + 1 }));
    storage.setTravel(withUpdatedOrder);
    storage.addActivity('Reordered travel stories', 'Travel');
    return withUpdatedOrder;
  },
};
