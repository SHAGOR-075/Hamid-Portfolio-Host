import { storage } from './storage';
import { delay } from './api';
import { HomeData } from '../types';

export const homeService = {
  getHomeData: async (): Promise<HomeData> => {
    await delay(150);
    return storage.getHome();
  },

  updateHomeData: async (data: HomeData): Promise<HomeData> => {
    await delay(300);
    storage.setHome(data);
    storage.addActivity('Updated Home hero configuration & tags', 'Home');
    return data;
  },
};
