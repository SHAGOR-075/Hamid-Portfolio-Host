import { storage } from './storage';
import { delay } from './api';
import { Project } from '../types';

export const projectService = {
  getProjects: async (): Promise<Project[]> => {
    await delay(150);
    return storage.getProjects();
  },

  getProjectById: async (id: string): Promise<Project | undefined> => {
    await delay(150);
    const projects = storage.getProjects();
    return projects.find((p) => p.id === id);
  },

  createProject: async (project: Omit<Project, 'id' | 'updatedAt'>): Promise<Project> => {
    await delay(300);
    const projects = storage.getProjects();
    const newProject: Project = {
      ...project,
      id: `proj_${Date.now()}`,
      slug: project.slug || project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      order: project.order || projects.length + 1,
      updatedAt: new Date().toISOString(),
    };
    const updated = [newProject, ...projects];
    storage.setProjects(updated);
    storage.addActivity(`Added new portfolio project "${newProject.title}"`, 'Projects');
    return newProject;
  },

  updateProject: async (id: string, updates: Partial<Project>): Promise<Project> => {
    await delay(250);
    const projects = storage.getProjects();
    const index = projects.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Project not found');
    const updated = {
      ...projects[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    projects[index] = updated;
    storage.setProjects(projects);
    storage.addActivity(`Updated project "${updated.title}"`, 'Projects');
    return updated;
  },

  deleteProject: async (id: string): Promise<void> => {
    await delay(250);
    const projects = storage.getProjects();
    const item = projects.find((p) => p.id === id);
    const filtered = projects.filter((p) => p.id !== id);
    storage.setProjects(filtered);
    if (item) {
      storage.addActivity(`Deleted project "${item.title}"`, 'Projects');
    }
  },

  toggleFeatured: async (id: string): Promise<Project> => {
    await delay(200);
    const projects = storage.getProjects();
    const project = projects.find((p) => p.id === id);
    if (!project) throw new Error('Project not found');
    const isNowFeatured = !project.featured;
    project.featured = isNowFeatured;
    storage.setProjects(projects);
    storage.addActivity(
      `Set project "${project.title}" featured status to ${isNowFeatured ? 'ON' : 'OFF'}`,
      'Projects'
    );
    return project;
  },

  reorderProjects: async (reordered: Project[]): Promise<Project[]> => {
    await delay(200);
    const withUpdatedOrder = reordered.map((p, idx) => ({ ...p, order: idx + 1 }));
    storage.setProjects(withUpdatedOrder);
    storage.addActivity('Reordered portfolio projects', 'Projects');
    return withUpdatedOrder;
  },
};
