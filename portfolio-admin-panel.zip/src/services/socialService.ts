import { storage } from './storage';
import { delay } from './api';
import { SocialLink, ContactData } from '../types';

export const socialService = {
  getSocials: async (): Promise<SocialLink[]> => {
    await delay(150);
    return storage.getSocials();
  },

  getSocialLinks: async (): Promise<SocialLink[]> => {
    await delay(150);
    return storage.getSocials();
  },

  updateSocialLinks: async (socials: SocialLink[]): Promise<SocialLink[]> => {
    await delay(250);
    storage.setSocials(socials);
    storage.addActivity('Updated social media channels & URLs', 'Social Links');
    return socials;
  },

  updateSocial: async (id: string, updates: Partial<SocialLink>): Promise<SocialLink> => {
    await delay(200);
    const list = storage.getSocials();
    const updated = list.map((s) => (s.id === id ? { ...s, ...updates } : s));
    storage.setSocials(updated);
    storage.addActivity('Updated social media channel', 'Social Links');
    return updated.find((s) => s.id === id)!;
  },

  createSocial: async (item: Omit<SocialLink, 'id'>): Promise<SocialLink> => {
    await delay(250);
    const list = storage.getSocials();
    const newItem: SocialLink = {
      ...item,
      id: `soc_${Date.now()}`,
      order: item.order || list.length + 1,
      active: item.active ?? true,
    };
    const updated = [...list, newItem];
    storage.setSocials(updated);
    storage.addActivity(`Added social network link for ${newItem.platform}`, 'Social Links');
    return newItem;
  },

  addSocialLink: async (item: Omit<SocialLink, 'id'>): Promise<SocialLink> => {
    return socialService.createSocial(item);
  },

  deleteSocial: async (id: string): Promise<void> => {
    await delay(200);
    const list = storage.getSocials();
    const filtered = list.filter((s) => s.id !== id);
    storage.setSocials(filtered);
    storage.addActivity('Removed social network link', 'Social Links');
  },

  deleteSocialLink: async (id: string): Promise<void> => {
    return socialService.deleteSocial(id);
  },

  reorderSocials: async (reordered: SocialLink[]): Promise<SocialLink[]> => {
    await delay(200);
    const withOrder = reordered.map((item, idx) => ({ ...item, order: idx + 1 }));
    storage.setSocials(withOrder);
    storage.addActivity('Reordered social profile priority', 'Social Links');
    return withOrder;
  },

  toggleSocialVisibility: async (id: string): Promise<SocialLink[]> => {
    await delay(150);
    const list = storage.getSocials();
    const updated = list.map((s) => (s.id === id ? { ...s, active: !s.active, visible: !s.visible } : s));
    storage.setSocials(updated);
    storage.addActivity('Toggled social profile visibility', 'Social Links');
    return updated;
  },
};

export const contactService = {
  getContactData: async (): Promise<ContactData> => {
    await delay(150);
    return storage.getContact();
  },

  updateContactData: async (data: ContactData): Promise<ContactData> => {
    await delay(250);
    storage.setContact(data);
    storage.addActivity('Updated portfolio contact details & preferences', 'Contact');
    return data;
  },
};
