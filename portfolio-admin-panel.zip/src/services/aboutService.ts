import { storage } from './storage';
import { delay } from './api';
import { AboutData } from '../types';

export const aboutService = {
  getAboutData: async (): Promise<AboutData> => {
    await delay(150);
    return storage.getAbout();
  },

  updateAboutData: async (data: AboutData): Promise<AboutData> => {
    await delay(300);
    storage.setAbout(data);
    storage.addActivity('Updated About section paragraphs & statistics', 'About');
    return data;
  },
};
