import { storage } from './storage';
import { delay } from './api';
import { Education } from '../types';

export const educationService = {
  getEducation: async (): Promise<Education[]> => {
    await delay(150);
    return storage.getEducation();
  },

  createEducation: async (edu: Omit<Education, 'id'>): Promise<Education> => {
    await delay(300);
    const list = storage.getEducation();
    const newEdu: Education = {
      ...edu,
      id: `edu_${Date.now()}`,
      order: edu.order || list.length + 1,
    };
    const updated = [...list, newEdu];
    storage.setEducation(updated);
    storage.addActivity(`Added educational qualification "${newEdu.degree}"`, 'Education');
    return newEdu;
  },

  updateEducation: async (id: string, updates: Partial<Education>): Promise<Education> => {
    await delay(250);
    const list = storage.getEducation();
    const index = list.findIndex((e) => e.id === id);
    if (index === -1) throw new Error('Education item not found');
    const updated = { ...list[index], ...updates };
    list[index] = updated;
    storage.setEducation(list);
    storage.addActivity(`Updated education "${updated.degree}"`, 'Education');
    return updated;
  },

  deleteEducation: async (id: string): Promise<void> => {
    await delay(250);
    const list = storage.getEducation();
    const item = list.find((e) => e.id === id);
    const filtered = list.filter((e) => e.id !== id);
    storage.setEducation(filtered);
    if (item) {
      storage.addActivity(`Deleted education entry "${item.degree}"`, 'Education');
    }
  },

  reorderEducation: async (reordered: Education[]): Promise<Education[]> => {
    await delay(200);
    const withUpdatedOrder = reordered.map((e, idx) => ({ ...e, order: idx + 1 }));
    storage.setEducation(withUpdatedOrder);
    storage.addActivity('Reordered education history timeline', 'Education');
    return withUpdatedOrder;
  },
};
