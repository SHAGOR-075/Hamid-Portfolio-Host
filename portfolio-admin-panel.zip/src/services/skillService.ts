import { storage } from './storage';
import { delay } from './api';
import { Skill } from '../types';

export const skillService = {
  getSkills: async (): Promise<Skill[]> => {
    await delay(150);
    return storage.getSkills();
  },

  createSkill: async (skill: Omit<Skill, 'id'>): Promise<Skill> => {
    await delay(300);
    const skills = storage.getSkills();
    const newSkill: Skill = {
      ...skill,
      id: `sk_${Date.now()}`,
      order: skill.order || skills.length + 1,
    };
    const updated = [...skills, newSkill];
    storage.setSkills(updated);
    storage.addActivity(`Created new skill "${newSkill.name}"`, 'Skills');
    return newSkill;
  },

  updateSkill: async (id: string, updates: Partial<Skill>): Promise<Skill> => {
    await delay(250);
    const skills = storage.getSkills();
    const index = skills.findIndex((s) => s.id === id);
    if (index === -1) throw new Error('Skill not found');
    const updatedSkill = { ...skills[index], ...updates };
    skills[index] = updatedSkill;
    storage.setSkills(skills);
    storage.addActivity(`Updated skill "${updatedSkill.name}"`, 'Skills');
    return updatedSkill;
  },

  deleteSkill: async (id: string): Promise<void> => {
    await delay(250);
    const skills = storage.getSkills();
    const skill = skills.find((s) => s.id === id);
    const filtered = skills.filter((s) => s.id !== id);
    storage.setSkills(filtered);
    if (skill) {
      storage.addActivity(`Deleted skill "${skill.name}"`, 'Skills');
    }
  },

  reorderSkills: async (reorderedSkills: Skill[]): Promise<Skill[]> => {
    await delay(200);
    const withUpdatedOrder = reorderedSkills.map((s, idx) => ({ ...s, order: idx + 1 }));
    storage.setSkills(withUpdatedOrder);
    storage.addActivity('Reordered technical skills list', 'Skills');
    return withUpdatedOrder;
  },
};
