import { storage } from './storage';
import { delay } from './api';
import { WebsiteSettings, ActivityLog } from '../types';

export const settingsService = {
  getSettings: async (): Promise<WebsiteSettings> => {
    await delay(150);
    return storage.getSettings();
  },

  updateSettings: async (settings: WebsiteSettings): Promise<WebsiteSettings> => {
    await delay(250);
    storage.setSettings(settings);
    storage.addActivity('Updated global website metadata & footer settings', 'Settings');
    return settings;
  },

  getActivityLogs: async (): Promise<ActivityLog[]> => {
    await delay(100);
    return storage.getActivities();
  },

  clearActivityLogs: async (): Promise<void> => {
    await delay(100);
    localStorage.removeItem('portfolio_admin_activities');
  },
};
