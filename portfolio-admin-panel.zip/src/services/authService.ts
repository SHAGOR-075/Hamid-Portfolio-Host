import { storage } from './storage';
import { delay } from './api';
import { User } from '../types';

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export const authService = {
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    await delay(400);

    // Mock validation - accepts admin@example.com (or any valid email format with length > 4)
    if (credentials.email && credentials.password.length >= 4) {
      const user = storage.getUser();
      const token = `jwt_mock_token_${Date.now()}`;
      storage.setToken(token);
      return { user, token };
    }
    throw new Error('Invalid email or password. Use admin@example.com / admin123');
  },

  logout: async (): Promise<void> => {
    await delay(150);
    storage.setToken(null);
  },

  getCurrentUser: async (): Promise<User | null> => {
    await delay(100);
    const token = storage.getToken();
    if (!token) return null;
    return storage.getUser();
  },

  updateProfile: async (userData: Partial<User>): Promise<User> => {
    await delay(300);
    const current = storage.getUser();
    const updated = { ...current, ...userData };
    storage.setUser(updated);
    storage.addActivity('Updated admin profile information', 'System');
    return updated;
  },

  changePassword: async (currentPass: string, newPass: string): Promise<boolean> => {
    await delay(400);
    if (!currentPass || !newPass || newPass.length < 6) {
      throw new Error('New password must be at least 6 characters.');
    }
    storage.addActivity('Changed admin account password', 'System');
    return true;
  },
};
