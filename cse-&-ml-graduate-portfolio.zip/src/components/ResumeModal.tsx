import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Download, Printer, ExternalLink, GraduationCap, Briefcase, Award, Sparkles, CheckCircle2 } from 'lucide-react';
import { profileData, educationData, mlProjectsData } from '../data/portfolioData';
import { skillsData } from '../data/skills';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative w-full max-w-4xl max-h-[90vh] bg-[#0A0E0C] text-white rounded-2xl border border-emerald-500/30 shadow-2xl overflow-hidden flex flex-col z-10"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-[#063B2A]/40 backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Sparkles size={18} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">Curriculum Vitae</h3>
                <p className="text-xs text-emerald-400 font-mono">B.Sc. in CSE • Machine Learning Track</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white transition-colors"
                title="Print or Save as PDF"
              >
                <Printer size={14} />
                <span>Print / PDF</span>
              </button>
              <a
                href={`mailto:${profileData.email}?subject=Full-time Opportunity for ${profileData.fullName}`}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-black transition-colors"
              >
                <Download size={14} />
                <span>Request Official PDF</span>
              </a>
              <button
                onClick={onClose}
                className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                aria-label="Close resume modal"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-8 print:p-0 print:text-black">
            {/* Header info */}
            <div className="border-b border-neutral-800 pb-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white">{profileData.fullName}</h1>
                  <p className="text-emerald-400 font-medium text-sm mt-0.5">{profileData.title}</p>
                </div>
                <div className="text-xs text-neutral-400 space-y-1 sm:text-right font-mono">
                  <p>{profileData.email}</p>
                  <p>{profileData.location}</p>
                  <p className="text-emerald-400/90">{profileData.availability}</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-neutral-300 leading-relaxed max-w-3xl">
                {profileData.bio.intro} {profileData.bio.body1}
              </p>
            </div>

            {/* Education */}
            <div>
              <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold uppercase tracking-wider mb-4">
                <GraduationCap size={16} />
                <span>Education</span>
              </div>
              <div className="space-y-4">
                {educationData.map((edu) => (
                  <div key={edu.id} className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                      <h4 className="font-bold text-white text-base">{edu.degree}</h4>
                      <span className="text-xs font-mono px-2.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 w-fit">
                        {edu.period}
                      </span>
                    </div>
                    <p className="text-sm text-emerald-300/90 font-medium">{edu.institution} — {edu.location}</p>
                    {edu.grade && <p className="text-xs text-neutral-400 font-mono mt-0.5">{edu.grade}</p>}
                    {edu.thesis && (
                      <div className="mt-3 p-3 rounded-lg bg-emerald-950/30 border border-emerald-500/20 text-xs">
                        <span className="font-semibold text-emerald-300">Undergraduate Thesis: </span>
                        <span className="text-neutral-300">{edu.thesis.title}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* ML Projects & Research */}
            <div>
              <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold uppercase tracking-wider mb-4">
                <Briefcase size={16} />
                <span>Selected Machine Learning Projects</span>
              </div>
              <div className="space-y-4">
                {mlProjectsData.map((proj) => (
                  <div key={proj.id} className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                      <h4 className="font-bold text-white text-base">{proj.title}</h4>
                      <span className="text-xs text-emerald-400 font-mono">{proj.category}</span>
                    </div>
                    <p className="text-xs text-neutral-300 mt-1 leading-relaxed">{proj.solution}</p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {proj.tags.map((tag) => (
                        <span key={tag} className="px-2 py-0.5 rounded text-[11px] font-mono bg-neutral-800 text-neutral-300">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Core Competencies */}
            <div>
              <div className="flex items-center gap-2 text-emerald-400 text-sm font-bold uppercase tracking-wider mb-4">
                <Award size={16} />
                <span>Key Technical Competencies</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
                  <p className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">Machine Learning & Math</p>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    PyTorch, Scikit-Learn, NumPy, Pandas, OpenCV, CNNs, Attention Mechanisms, Feature Engineering, Grad-CAM, EDA, Matrix Algebra.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800/80">
                  <p className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2">Software Engineering & Tools</p>
                  <p className="text-xs text-neutral-300 leading-relaxed">
                    Python, C/C++, JavaScript (ES6+), TypeScript, React, Node.js, Express, Tailwind CSS, Git/GitHub, Linux, Docker, Jupyter.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer CTA */}
          <div className="px-6 py-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs text-neutral-400">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <CheckCircle2 size={14} /> Available immediately for ML Engineer / Software Engineer roles
            </span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
